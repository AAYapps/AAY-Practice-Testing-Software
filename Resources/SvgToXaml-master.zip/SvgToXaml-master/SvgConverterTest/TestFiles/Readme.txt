some of these icons are copyrighted by iconmonstr.com
Please respect copyright!